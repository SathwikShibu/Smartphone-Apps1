package com.example.nancalculatorapp

import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import com.example.carapplication.R

class MainActivity : AppCompatActivity() {
    private lateinit var noiseInput: EditText
    private lateinit var airInput: EditText
    private lateinit var navInput: EditText
    private lateinit var resultText: TextView
    private lateinit var calculateBtn: Button

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        noiseInput = findViewById(R.id.noiseInput)
        airInput = findViewById(R.id.airInput)
        navInput = findViewById(R.id.navInput)
        resultText = findViewById(R.id.resultText)
        calculateBtn = findViewById(R.id.calculateBtn)

        calculateBtn.setOnClickListener {
            val noise = noiseInput.text.toString().toDoubleOrNull() ?: 0.0
            val air = airInput.text.toString().toDoubleOrNull() ?: 0.0
            val nav = navInput.text.toString().toDoubleOrNull() ?: 0.0

            val result = calculateNan(noise, air, nav)
            resultText.text = "Result: $result"
        }
    }

    private fun calculateNan(noise: Double, air: Double, nav: Double): Double {
        return (noise + air + nav) / 3 // Example formula
    }
}
