package com.example.carapplication;

import android.app.Activity;

public class MainActivity extends Activity {
}
