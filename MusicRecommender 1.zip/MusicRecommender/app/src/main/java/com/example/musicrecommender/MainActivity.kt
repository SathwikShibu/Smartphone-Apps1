package com.example.musicrecommender

import android.os.Bundle
import android.widget.Button
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {
    private var selectedGenre: String? = null
    private var selectedMood: String? = null

    private val recommendations = mapOf(
        "Pop" to mapOf(
            "Chill" to listOf("Blinding Lights – The Weeknd", "Levitating – Dua Lipa", "Watermelon Sugar – Harry Styles"),
            "Energetic" to listOf("Uptown Funk – Mark Ronson ft. Bruno Mars", "Shake It Off – Taylor Swift", "Can't Stop the Feeling – Justin Timberlake"),
            "Focus" to listOf("Someone Like You – Adele", "Fix You – Coldplay", "Paradise – Coldplay"),
            "Relaxed" to listOf("Stay With Me – Sam Smith", "Photograph – Ed Sheeran", "Slow Hands – Niall Horan"),
            "Party" to listOf("Party in the U.S.A. – Miley Cyrus", "Get Lucky – Daft Punk", "Can't Feel My Face – The Weeknd"),
            "Melancholy" to listOf("When I Was Your Man – Bruno Mars", "All I Want – Kodaline", "Let Her Go – Passenger")
        ),
        "Rock" to mapOf(
            "Chill" to listOf("Wish You Were Here – Pink Floyd", "Cinnamon Girl – Neil Young", "Blackbird – The Beatles"),
            "Energetic" to listOf("Don't Stop Me Now – Queen", "Smells Like Teen Spirit – Nirvana", "Thunderstruck – AC/DC"),
            "Focus" to listOf("Bohemian Rhapsody – Queen", "Hotel California – Eagles", "Sweet Child O' Mine – Guns N' Roses"),
            "Relaxed" to listOf("Under the Bridge – Red Hot Chili Peppers", "Patience – Guns N' Roses", "Everlong (Acoustic) – Foo Fighters"),
            "Party" to listOf("Livin' on a Prayer – Bon Jovi", "You Shook Me All Night Long – AC/DC", "Eye of the Tiger – Survivor"),
            "Melancholy" to listOf("Hurt – Johnny Cash", "Nutshell – Alice In Chains", "Wish You Were Here – Pink Floyd")
        ),
        "Jazz" to mapOf(
            "Chill" to listOf("So What – Miles Davis", "Take Five – The Dave Brubeck Quartet", "My Favorite Things – John Coltrane"),
            "Energetic" to listOf("Sing, Sing, Sing – Benny Goodman", "Cantaloupe Island – Herbie Hancock", "Birdland – Weather Report"),
            "Focus" to listOf("Blue in Green – Miles Davis", "In a Sentimental Mood – Duke Ellington", "Round Midnight – Thelonious Monk"),
            "Relaxed" to listOf("Autumn Leaves – Bill Evans", "My Funny Valentine – Chet Baker", "Summertime – Ella Fitzgerald"),
            "Party" to listOf("It Don't Mean a Thing – Duke Ellington", "Moanin' – Art Blakey", "Take the 'A' Train – Duke Ellington"),
            "Melancholy" to listOf("Goodbye Pork Pie Hat – Charles Mingus", "Naima – John Coltrane", "Strange Fruit – Billie Holiday")
        ),
        "Hip-Hop" to mapOf(
            "Chill" to listOf("N.Y. State of Mind – Nas", "Juicy – Notorious B.I.G.", "The World Is Yours – Nas"),
            "Energetic" to listOf("Lose Yourself – Eminem", "Power – Kanye West", "HUMBLE. – Kendrick Lamar"),
            "Focus" to listOf("The Message – Grandmaster Flash", "Rockstar – Post Malone ft. 21 Savage", "Changes – Tupac"),
            "Relaxed" to listOf("C.R.E.A.M. – Wu-Tang Clan", "God's Plan – Drake", "Slow Down – Bobby Valentino"),
            "Party" to listOf("Hypnotize – Notorious B.I.G.", "Old Town Road – Lil Nas X", "Gold Digger – Kanye West"),
            "Melancholy" to listOf("Sing About Me – Kendrick Lamar", "Song Cry – Jay-Z", "All We Got – Chance The Rapper")
        ),
        "Classical" to mapOf(
            "Chill" to listOf("Clair de Lune – Debussy", "Gymnopédie No.1 – Satie", "Moonlight Sonata – Beethoven"),
            "Energetic" to listOf("Flight of the Bumblebee – Rimsky-Korsakov", "William Tell Overture – Rossini", "Hungarian Rhapsody No.2 – Liszt"),
            "Focus" to listOf("Spring from The Four Seasons – Vivaldi", "Brandenburg Concerto No.3 – Bach", "Canon in D – Pachelbel"),
            "Relaxed" to listOf("Spiegel im Spiegel – Pärt", "Nocturne Op.9 No.2 – Chopin", "The Swan – Saint-Saëns"),
            "Party" to listOf("Radetzky March – Strauss", "William Tell Overture (Finale) – Rossini", "In the Hall of the Mountain King – Grieg"),
            "Melancholy" to listOf("Adagio for Strings – Barber", "Pavane – Fauré", "Adagio in G Minor – Albinoni")
        ),
        "Electronic" to mapOf(
            "Chill" to listOf("Porcelain – Moby", "Night Owl – Galimatias", "Weightless – Marconi Union"),
            "Energetic" to listOf("One More Time – Daft Punk", "Levels – Avicii", "Titanium – David Guetta ft. Sia"),
            "Focus" to listOf("Midnight City – M83", "Cirrus – Bonobo", "Opus – Eric Prydz"),
            "Relaxed" to listOf("Sunset Lover – Petit Biscuit", "Silent Shout – The Knife", "Into the Trees – Tinlicker"),
            "Party" to listOf("Animals – Martin Garrix", "Lean On – Major Lazer", "Wake Me Up – Avicii"),
            "Melancholy" to listOf("Strobe – Deadmau5", "Opus – Eric Prydz", "We Can't Stop – Andrew Luce")
        )
    )

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val genreButtons = listOf(
            findViewById<Button>(R.id.btnGenrePop),
            findViewById<Button>(R.id.btnGenreRock),
            findViewById<Button>(R.id.btnGenreJazz),
            findViewById<Button>(R.id.btnGenreHipHop),
            findViewById<Button>(R.id.btnGenreClassical),
            findViewById<Button>(R.id.btnGenreElectronic)
        )
        val moodButtons = listOf(
            findViewById<Button>(R.id.btnMoodChill),
            findViewById<Button>(R.id.btnMoodEnergetic),
            findViewById<Button>(R.id.btnMoodFocus),
            findViewById<Button>(R.id.btnMoodRelaxed),
            findViewById<Button>(R.id.btnMoodParty),
            findViewById<Button>(R.id.btnMoodMelancholy)
        )
        val btnRecommend = findViewById<Button>(R.id.btnRecommend)
        val btnClear = findViewById<Button>(R.id.btnClear)
        val tvResults = findViewById<TextView>(R.id.tvResults)

        findViewById<Button>(R.id.btnInstructions).setOnClickListener {
            InstructionsDialog().show(supportFragmentManager, "instr")
        }

        fun clearGenreSelection() {
            genreButtons.forEach { it.alpha = 1f }
        }
        fun clearMoodSelection() {
            moodButtons.forEach { it.alpha = 1f }
        }

        genreButtons.forEach { btn ->
            btn.setOnClickListener {
                selectedGenre = btn.text.toString()
                clearGenreSelection()
                btn.alpha = 0.5f
            }
        }
        moodButtons.forEach { btn ->
            btn.setOnClickListener {
                selectedMood = btn.text.toString()
                clearMoodSelection()
                btn.alpha = 0.5f
            }
        }

        btnRecommend.setOnClickListener {
            if (selectedGenre == null || selectedMood == null) {
                Toast.makeText(this, "Please select both a genre and a mood.", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }
            val list = recommendations[selectedGenre]?.get(selectedMood)
            tvResults.text = list?.joinToString("\n") { "• $it" }
                ?: "Sorry, no songs found for $selectedGenre + $selectedMood."
        }

        btnClear.setOnClickListener {
            selectedGenre = null
            selectedMood = null
            clearGenreSelection()
            clearMoodSelection()
            tvResults.text = "Your playlist will appear here…"
        }
    }
}
