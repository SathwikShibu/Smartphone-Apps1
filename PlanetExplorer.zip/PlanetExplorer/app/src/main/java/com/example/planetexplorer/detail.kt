package com.example.planetexplorer

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import com.example.planetexplorer.databinding.ActivityDetailBinding

class detail : AppCompatActivity() {

    private lateinit var binding: ActivityDetailBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityDetailBinding.inflate(layoutInflater)
        setContentView(binding.root)

        val planetName = intent.getStringExtra("planet_name") ?: "Unknown"
        binding.txtPlanetName.text = planetName

        when (planetName) {
            "Mercury" -> {
                binding.imgPlanet.setImageResource(R.drawable.mercury)
                binding.txtDescription.text = "Mercury is the closest planet to the Sun and has no atmosphere."
                binding.txtDiameter.text = "4,879 km"
                binding.txtTemperature.text = "−173 to 427°C"
                binding.txtOrbit.text = "88 Earth days to orbit the Sun"
                binding.txtFunFact.text = "Mercury has no moons!"
            }

            "Venus" -> {
                binding.imgPlanet.setImageResource(R.drawable.venus)
                binding.txtDescription.text = "Venus is covered in thick clouds and has a runaway greenhouse effect."
                binding.txtDiameter.text = "12,104 km"
                binding.txtTemperature.text = "471°C (hottest planet)"
                binding.txtOrbit.text = "225 Earth days to orbit the Sun"
                binding.txtFunFact.text = "A day on Venus is longer than its year!"
            }

            "Earth" -> {
                binding.imgPlanet.setImageResource(R.drawable.earth)
                binding.txtDescription.text = "Earth is the only known planet that supports life."
                binding.txtDiameter.text = "12,742 km"
                binding.txtTemperature.text = "−88 to 58°C"
                binding.txtOrbit.text = "365.25 days to orbit the Sun"
                binding.txtFunFact.text = "70% of Earth's surface is covered by water."
            }

            "Mars" -> {
                binding.imgPlanet.setImageResource(R.drawable.mars)
                binding.txtDescription.text = "Mars is known as the Red Planet due to iron oxide on its surface."
                binding.txtDiameter.text = "6,779 km"
                binding.txtTemperature.text = "−125 to 20°C"
                binding.txtOrbit.text = "687 Earth days"
                binding.txtFunFact.text = "Mars has the tallest volcano in the solar system (Olympus Mons)."
            }

            "Jupiter" -> {
                binding.imgPlanet.setImageResource(R.drawable.jupiter)
                binding.txtDescription.text = "Jupiter is the largest planet, made mostly of gas."
                binding.txtDiameter.text = "139,820 km"
                binding.txtTemperature.text = "−145°C"
                binding.txtOrbit.text = "12 Earth years"
                binding.txtFunFact.text = "Jupiter has a giant storm called the Great Red Spot."
            }

            "Saturn" -> {
                binding.imgPlanet.setImageResource(R.drawable.saturn)
                binding.txtDescription.text = "Saturn is famous for its beautiful ring system."
                binding.txtDiameter.text = "116,460 km"
                binding.txtTemperature.text = "−178°C"
                binding.txtOrbit.text = "29 Earth years"
                binding.txtFunFact.text = "Saturn could float in water because it's so light!"
            }

            "Uranus" -> {
                binding.imgPlanet.setImageResource(R.drawable.uranus)
                binding.txtDescription.text = "Uranus rotates on its side and has a bluish color."
                binding.txtDiameter.text = "50,724 km"
                binding.txtTemperature.text = "−224°C"
                binding.txtOrbit.text = "84 Earth years"
                binding.txtFunFact.text = "Uranus has 27 moons and 13 rings."
            }

            "Neptune" -> {
                binding.imgPlanet.setImageResource(R.drawable.neptune)
                binding.txtDescription.text = "Neptune is a deep blue gas giant with extreme winds."
                binding.txtDiameter.text = "49,244 km"
                binding.txtTemperature.text = "−214°C"
                binding.txtOrbit.text = "165 Earth years"
                binding.txtFunFact.text = "Neptune has the fastest winds in the solar system!"
            }

            "Pluto" -> {
                binding.imgPlanet.setImageResource(R.drawable.pluto)
                binding.txtDescription.text = "Pluto is a dwarf planet in the Kuiper Belt."
                binding.txtDiameter.text = "2,377 km"
                binding.txtTemperature.text = "−229°C"
                binding.txtOrbit.text = "248 Earth years"
                binding.txtFunFact.text = "Pluto has 5 moons; the largest is Charon."
            }

            "Sun" -> {
                binding.imgPlanet.setImageResource(R.drawable.sun)
                binding.txtDescription.text = "The Sun is the star at the center of the solar system."
                binding.txtDiameter.text = "1.39 million km"
                binding.txtTemperature.text = "5,500°C on surface, 15 million °C in core"
                binding.txtOrbit.text = "The Sun doesn’t orbit, but planets orbit it."
                binding.txtFunFact.text = "The Sun accounts for 99.8% of the solar system’s mass."
            }

            else -> {
                binding.imgPlanet.setImageResource(R.mipmap.ic_launcher_foreground)
                binding.txtDescription.text = "No information available."
                binding.txtDiameter.text = "—"
                binding.txtTemperature.text = "—"
                binding.txtOrbit.text = "—"
                binding.txtFunFact.text = "—"
            }
        }

        binding.btnBack.setOnClickListener {
            finish()
        }
    }
}

