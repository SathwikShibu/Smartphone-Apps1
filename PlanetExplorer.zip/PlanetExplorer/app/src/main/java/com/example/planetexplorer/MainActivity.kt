package com.example.planetexplorer

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.LinearLayout
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }

        // Planet click listeners
        findViewById<LinearLayout>(R.id.btnMercury).setOnClickListener { openPlanetDetail("Mercury") }
        findViewById<LinearLayout>(R.id.btnVenus).setOnClickListener { openPlanetDetail("Venus") }
        findViewById<LinearLayout>(R.id.btnEarth).setOnClickListener { openPlanetDetail("Earth") }
        findViewById<LinearLayout>(R.id.btnMars).setOnClickListener { openPlanetDetail("Mars") }
        findViewById<LinearLayout>(R.id.btnJupiter).setOnClickListener { openPlanetDetail("Jupiter") }
        findViewById<LinearLayout>(R.id.btnSaturn).setOnClickListener { openPlanetDetail("Saturn") }
        findViewById<LinearLayout>(R.id.btnUranus).setOnClickListener { openPlanetDetail("Uranus") }
        findViewById<LinearLayout>(R.id.btnNeptune).setOnClickListener { openPlanetDetail("Neptune") }
        findViewById<LinearLayout>(R.id.btnPluto).setOnClickListener { openPlanetDetail("Pluto") }
        findViewById<LinearLayout>(R.id.btnSun).setOnClickListener { openPlanetDetail("Sun") }

        // Info modal
        findViewById<Button>(R.id.btnInfo).setOnClickListener {
            AlertDialog.Builder(this)
                .setTitle("About Planet Explorer")
                .setMessage("Tap any planet or celestial body to learn interesting facts about it.")
                .setPositiveButton("OK") { dialog, _ -> dialog.dismiss() }
                .show()
        }
    }

    private fun openPlanetDetail(planetName: String) {
        val intent = Intent(this, detail::class.java)
        intent.putExtra("planet_name", planetName)
        startActivity(intent)
    }
}
